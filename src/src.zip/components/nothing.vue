<template>
  <div class="nothing">
    <img style="width: 40%;" src="@/assets/images/nothing.svg" alt="">
  </div>
</template>

<script>
</script>

<style>
  .nothing{
    width: 100%;
    height: 60vh;
    display: flex;
    justify-content: center;
    align-items: center;
  }
</style>

<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
  export default {
    name: 'App'
  }
</script>
<style>
  .cur {
    cursor: pointer;
  }

  i {
    cursor: pointer;
  }

  .el-tag--dark {
    border-color: #fff !important;
  }
</style>
